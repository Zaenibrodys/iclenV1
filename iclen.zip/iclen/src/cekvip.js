const cekvip = () => { 
	return `           
──────────────────
*Nama bot* :  𝑁𝐼𝐶𝑂 𝐵𝑂𝑇
──────────────────
        『 *𝐕𝐈𝐏 𝐔𝐒𝐄𝐑* 』
──────────────────
• *Status*    : *ACTIVE*
────────────────── 
*Status Bot:* *Online*
────────────────── `
}
exports.cekvip = cekvip