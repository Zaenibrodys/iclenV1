const makermenu = (prefix) => { 
	return `
╔══✪〘 MAKER 〙✪══
║
╰─⊱ *${prefix}tahta* [iki]
╰─⊱ *${prefix}logo* [anker]
╰─⊱ *${prefix}goldbutton* [anker]
╰─⊱ *${prefix}silverbutton* [anker]
╰─⊱ *${prefix}pronlogo* [text|text]
╰─⊱ *${prefix}snow* [text|text]
╰─⊱ *${prefix}marvelogo* [text|text]
╰─⊱ *${prefix}text3d* [text]
╰─⊱ *${prefix}ninjalogo* [text|text]
╰─⊱ *${prefix}wolflogo* [text|text]
╰─⊱ *${prefix}lionlogo* [text|text]
╰─⊱ *${prefix}textscreen* [text
╰─⊱ *${prefix}rtext* [text]
╰─⊱ *${prefix}party* [text]
╰─⊱ *${prefix}light* [text]
╰─⊱ *${prefix}shadow* [text]
╰─⊱ *${prefix}minion* [text]
╰─⊱ *${prefix}neon* [text]
╰─⊱ *${prefix}neongreen* [text]
╰─⊱ *${prefix}neon2* [text]
╰─⊱ *${prefix}3d* [text]
╰─⊱ *${prefix}blackpink* [text]
╰─⊱ *${prefix}sandwriting* [text]
╰─⊱ *${prefix}water* [text|text]
╰─⊱ *${prefix}thunder* [text]
╰─⊱ *${prefix}stiltext* [text|text]
╰─⊱ *${prefix}party* [text]
╰─⊱ *${prefix}galaxtext* [text]
╰─⊱ *${prefix}lovemake* [text]
╰─⊱ *${prefix}walpaperhd* [text]
╰─⊱ *${prefix}fire* [text]
╰─⊱ *${prefix}quotemaker* [tx|tx|random]
╰─⊱ *${prefix}water* [text]
╰─⊱ *${prefix}epep* [text]
╰─⊱ *${prefix}glitch* [text]
╰─⊱ *${prefix}jokerlogo [teks]*
║
╚═〘  RIU BOT 〙`
}
exports.makermenu = makermenu