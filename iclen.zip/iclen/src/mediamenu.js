const mediamenu = (prefix) => { 
	return `

╔══✪〘 MEDIA 〙✪══
║
╰─⊱ *${prefix}yt* [link]
╰─⊱ *${prefix}tiktok* [link]
╰─⊱ *${prefix}ytsearch* [yt search]
╰─⊱ *${prefix}lirik* [judul lagu]
╰─⊱ *${prefix}chord* [judul lagu]
╰─⊱ *${prefix}igstalk* [Rizky]
╰─⊱ *${prefix}wikien* [love]
╰─⊱ *${prefix}tiktokstalk* [username]
╰─⊱ *${prefix}url2img* [link]
╰─⊱ *${prefix}fototiktok* [username]
╰─⊱ *${prefix}map* [kota]
╰─⊱ *${prefix}kbbi* [kamus]
╰─⊱ *${prefix}brainly* [tau sendiri kan]
╰─⊱ *${prefix}infoghitub* 
╰─⊱ *${prefix}infocuaca* [kota]
╰─⊱ *${prefix}infogempa*
╰─⊱ *${prefix}artinama [nama]*
╰─⊱ *${prefix}covid [negara]*
╰─⊱ *${prefix}nulis [teks]*
╰─⊱ *${prefix}sandwriting [teks]*
╰─⊱ *${prefix}quotemaker [|teks|author|theme]*
╰─⊱ *${prefix}resepmasakan [optional]*
╰─⊱ *${prefix}tts [kode bhs] [teks]*
╰─⊱ *${prefix}igstalk [@username]*
╰─⊱ *${prefix}tiktokstalk [@username]*
╰─⊱ *${prefix}wiki [query]*
╰─⊱ *${prefix}qrcode [optional]*
╰─⊱ *${prefix}map [optional]*
╰─⊱ *${prefix}textmaker [teks1|teks2]*
╰─⊱ *${prefix}ssweb [linkWeb]*
╰─⊱ *${prefix}shorturl [linkWeb]*
╰─⊱ *${prefix}animesaran*
╰─⊱ *${prefix}animesaran2*
║
╚═〘  RIU BOT 〙`
}
exports.mediamenu = mediamenu