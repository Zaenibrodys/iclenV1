const vipmenu = (prefix) => { 
	return `            
	
╔══✪〘 VIP USER 〙✪══
║
╰─⊱ *${prefix}ytmp4 [link]*
╰─⊱ *${prefix}ytmp3 [link]*
╰─⊱ *${prefix}hidetag2*
╰─⊱ *${prefix}joox [lagu]*
╰─⊱ *${prefix}setprefix*
╰─⊱ *${prefix}tomp3 [replay video]*
╰─⊱  *${prefix}randomanime*
╰─⊱  *${prefix}randomhentai*
╰─⊱  *${prefix}nsfwloli*
╰─⊱  *${prefix}nsfwblowjob*
╰─⊱  *${prefix}nsfwneko*
╰─⊱  *${prefix}nsfwtrap*
╰─⊱  *${prefix}indohot*
╰─⊱  *${prefix}otagall2*
╰─⊱  *${prefix}otagall3*
╰─⊱  *${prefix}hidetag5*
╰─⊱  *${prefix}indo(1-25)*
╰─⊱  *CONTOH ${prefix}indo1*
║
╚══✪〘  RIU BOT 〙✪══
`
}
exports.vipmenu = vipmenu